# GT Launcher (Unofficial Modified Version)

مشغل مخصص لتشغيل لعبة Minecraft Java Edition على أجهزة الأندرويد بكفاءة عالية وأداء محسّن.
