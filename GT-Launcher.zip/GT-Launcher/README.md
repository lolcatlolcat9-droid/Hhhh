# GT Launcher (Unofficial Modified Version)

مشغل مخصص لتشغيل لعبة Minecraft Java Edition على أجهزة الأندرويد بكفاءة عالية وأداء محسّن.

## ⚠️ حقوق النشر والتنويه (License & Credits)
هذا المشروع هو نسخة معدلة غير رسمية (**Unofficial Modified Version**) يعتمد بشكل أساسي على النواة البرمجية المفتوحة المصدر للمشروعين:
* **PojavLauncher**
* **ZalithLauncher2**

### الترخيص (License)
هذا المشروع مرخص بالكامل تحت رخصة **GNU General Public License v3.0 (GPLv3)**.
يجب الحفاظ على إشعارات حقوق النشر الخاصة بالمطورين الأصليين عند إعادة استخدام أو تعديل الكود.
