package net.kdt.pojavlaunch

import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity()
