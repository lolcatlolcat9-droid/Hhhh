package net.kdt.pojavlaunch

object Tools {
    fun setAndroidVersion() {}
}
