package com.gt.launcher.core

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import java.io.File
import net.kdt.pojavlaunch.MainActivity as PojavMainActivity
import net.kdt.pojavlaunch.Tools

object GTLaunchManager {

    fun launchMinecraft(context: Context, versionName: String, jrePath: File) {
        val minecraftHome = File(context.filesDir, ".minecraft")
        if (!minecraftHome.exists()) {
            minecraftHome.mkdirs()
        }

        savePojavPreferences(context, versionName)
        setupEnvironment(context)

        val launchIntent = Intent(context, PojavMainActivity::class.java).apply {
            putExtra("versionId", versionName)
            putExtra("minecraftHome", minecraftHome.absolutePath)
            putExtra("jrePath", jrePath.absolutePath)
            putExtra("maxMemoryMB", 2048)
        }

        context.startActivity(launchIntent)
    }

    private fun savePojavPreferences(context: Context, versionName: String) {
        val prefs: SharedPreferences = context.getSharedPreferences("pojavconfig", Context.MODE_PRIVATE)
        prefs.edit().apply {
            putString("lastVersion", versionName)
            putString("curAccount", "GTPlayer")
            putBoolean("isLocalAccount", true)
            putInt("allocation", 2048)
            apply()
        }
    }

    private fun setupEnvironment(context: Context) {
        val nativeLibDir = File(context.applicationInfo.nativeLibraryDir)
        System.setProperty("java.library.path", nativeLibDir.absolutePath)
        
        try {
            Tools.setAndroidVersion()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
