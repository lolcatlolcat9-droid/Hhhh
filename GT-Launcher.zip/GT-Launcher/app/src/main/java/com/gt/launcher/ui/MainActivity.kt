package com.gt.launcher.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gt.launcher.R
import com.gt.launcher.core.GTLaunchManager
import java.io.File

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etVersion = findViewById<EditText>(R.id.etVersion)
        val btnPlay = findViewById<Button>(R.id.btnPlay)

        btnPlay.setOnClickListener {
            val versionName = etVersion.text.toString().trim()
            if (versionName.isEmpty()) {
                Toast.makeText(this, "الرجاء إدخال رقم الإصدار أولاً!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "جاري تجهيز الإصدار $versionName...", Toast.LENGTH_SHORT).show()
            
            val jrePath = File(filesDir, "runtimes/jre-17")
            GTLaunchManager.launchMinecraft(this, versionName, jrePath)
        }
    }
}
